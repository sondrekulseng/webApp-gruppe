Gruppeoppgave i webapplikasjoner, del 1

Frontend teknologier:
  - HTML, CSS og JavaScript
  - Bruker jQuery (JS bibliotek) for å kommunisere med backend via. POST og GET.
  - Bootstrap (CSS bibliotek) brukes for å designe deler av siden.

Backend teknologier:
  - C# ASP.NET
  - sqllite database

NB: I noen tilfeller når man starter programmet for første gang så kan serveren produsere en 500 error. Løsningen er da å restarte programmet.
